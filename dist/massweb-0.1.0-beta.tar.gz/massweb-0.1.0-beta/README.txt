Hyperion Gray, LLC
http://www.hyperiongray.com

===Purpose===

MassWeb is a simple, scalable and super-fast web app fuzzer.

==Documentation==

https://hyperiongray.atlassian.net/wiki/display/PUB/MassWeb

==License==

MassWeb is released under the Apache 2.0 License.
