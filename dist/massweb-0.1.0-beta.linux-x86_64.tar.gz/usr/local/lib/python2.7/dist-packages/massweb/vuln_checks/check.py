class Check(object):

    def check(self):

        raise Exception("Not Implemented Error")
